CMAKE_GHS_NO_SOURCE_GROUP_FILE
------------------------------

.. versionadded:: 3.14

``ON`` / ``OFF`` boolean to control if the project file for a target should
be one single file or multiple files.  Refer to
:prop_tgt:`GHS_NO_SOURCE_GROUP_FILE` for further details.
