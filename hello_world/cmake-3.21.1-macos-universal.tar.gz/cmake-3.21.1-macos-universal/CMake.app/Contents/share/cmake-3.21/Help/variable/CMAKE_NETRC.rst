CMAKE_NETRC
-----------

.. versionadded:: 3.11

This variable is used to initialize the ``NETRC`` option for
:command:`file(DOWNLOAD)` and :command:`file(UPLOAD)` commands and the
module :module:`ExternalProject`. See those commands for additional
information.

The local option takes precedence over this variable.
