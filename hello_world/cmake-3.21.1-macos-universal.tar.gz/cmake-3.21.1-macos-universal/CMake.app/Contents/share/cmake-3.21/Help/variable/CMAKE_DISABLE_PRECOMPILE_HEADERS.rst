CMAKE_DISABLE_PRECOMPILE_HEADERS
--------------------------------

.. versionadded:: 3.16

Default value for :prop_tgt:`DISABLE_PRECOMPILE_HEADERS` of targets.

By default ``CMAKE_DISABLE_PRECOMPILE_HEADERS`` is ``OFF``.
