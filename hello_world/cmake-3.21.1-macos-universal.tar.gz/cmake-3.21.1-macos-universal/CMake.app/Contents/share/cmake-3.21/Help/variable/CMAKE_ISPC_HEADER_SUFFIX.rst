CMAKE_ISPC_HEADER_SUFFIX
------------------------

.. versionadded:: 3.19.2

Output suffix to be used for ISPC generated headers.

This variable is used to initialize the :prop_tgt:`ISPC_HEADER_SUFFIX`
property on all the targets.  See the target property for additional
information.
